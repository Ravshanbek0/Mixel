import React from 'react'
import './Navbar.css'
import { HiOutlineMicrophone } from "react-icons/hi2";
import { CiSearch } from "react-icons/ci";
import { AiOutlineUser } from "react-icons/ai";
import { FaBalanceScale } from "react-icons/fa";
import { FaRegHeart } from "react-icons/fa6";
import { SlBasket } from "react-icons/sl";
import { Link } from 'react-router-dom';

function Navbar() {
    return (
        <>
            <div className="red-nav">
                <div className="container">
                    <div className="nav-red">
                        <h1>Ташкент</h1>
                        <ul>
                            <li>Наши магазины</li>
                            <li>B2B продажи</li>
                            <li>Покупка в рассрочку</li>
                            <li>Способы оплаты</li>
                            <li>Гарантия на товары</li>
                        </ul>
                        <div>
                            <p>+998 95 123 55 88  </p>
                            <p>Рус</p>
                        </div>
                    </div>
                </div>
            </div>
            <div className='container' >

                <nav className="nav-bar">
                    <Link to={'/'}><img src="../public/imgs/logo.png" alt="" className="logo-img" /></Link>
                    <div className="nav-search">
                        <select name="" id="select">
                            <option value="">Все категории</option>
                        </select>
                        <input type="text" placeholder='Телефоны и бытовая' />
                        <span className="micro-scan"><HiOutlineMicrophone /></span>
                        <button>
                            <span><CiSearch /></span>
                            Поиск
                        </button>
                    </div>
                    <div className="extras">
                        <div>
                            {/* <div className="red-cirlce">12</div> */}
                            <span className="icons-extra"><AiOutlineUser /></span> Войти
                        </div>
                        <div>
                            <h4 className="red-cirlce">12</h4>
                            <span className="icons-extra"><FaBalanceScale /></span> Сравнение
                        </div>
                        <div>
                            <h4 className="red-cirlce">12</h4>
                            <span className="icons-extra"><FaRegHeart /></span> Избранное
                        </div>
                        <div>
                            <h4 className="red-cirlce">12</h4>
                            <span className="icons-extra"><SlBasket /></span> Корзина
                        </div>
                    </div>
                </nav>

            </div>

        </>
    )
}

export default Navbar