import React from 'react'
import './GarCard.css'
import { AiOutlineUser } from "react-icons/ai";
import { FaBalanceScale } from "react-icons/fa";
import { FaRegHeart } from "react-icons/fa6";
import { SlBasket } from "react-icons/sl";

function GarCard() {
    return (
        <div className='gar-card'>
            <div className="discount">-3%</div>
            <img src="../public/imgs/garcard.png" alt="" />
            <h3><span>1 373 000 сум</span>  1 304 000 сум</h3>
            <h1>Телефон TECNO Spark 6 Go
                KE5j 3/64GB Ice Jadeite</h1>
            <p>Предложение заканчивается через:</p>
            <div className="minutes">
                <h4><span id="minute-num">27</span> <span className='minute-text' >ДНЕЙ</span> </h4>
                <h4><span id="minute-num">21</span> <span className='minute-text' >ЧАСОВ</span> </h4>
                <h4><span id="minute-num">10</span> <span className='minute-text' >МИНУТ</span> </h4>
                <h4><span id="minute-num">05</span> <span className='minute-text' >СЕКУНД</span> </h4>
            </div>
            <div className="gar-icons">
                <span><SlBasket  className='gar-iconb red' /></span>
                <span ><FaRegHeart  className='gar-iconb' /></span>
                <span><FaBalanceScale  className='gar-iconb' /></span>
            </div>
        </div>
    )
}

export default GarCard