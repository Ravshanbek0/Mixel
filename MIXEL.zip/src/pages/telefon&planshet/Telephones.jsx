import React, { useState } from 'react'
import './Telephones.css'
import { FaCoins } from "react-icons/fa";
import { BiMenuAltLeft } from "react-icons/bi";
import { IoGridOutline } from "react-icons/io5";
import { CiGrid2H } from "react-icons/ci";
import ToolCard from '../../components/tool-card/ToolCard';
// import ContinuousSlider from '../../components/range/RangeSlider';

import Accordion from '@mui/material/Accordion';
import AccordionActions from '@mui/material/AccordionActions';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
// import ExpandMoreIcon from '@mui/icons-material/ExpandMore';

import { FaAngleDown } from "react-icons/fa";

//Slider/////////////////////////////////

import Box from '@mui/material/Box';
import Slider from '@mui/material/Slider';

/////Cehch===///
import Checkbox from '@mui/material/Checkbox';

const label = { inputProps: { 'aria-label': 'Checkbox demo' } };

function Telephones({data}) {
    const [product, setProduct] = useState(data)

    ////////////////////Label values//////////////////
    const [value, setValue] = useState([20, 37]);
    const [brand, setBrand] = useState([]);
    const [battery, setBattery] = useState([]);
    const [country, setCountry] = useState([]);
    /////////////////////////////////////////////////

    const [isActive, setIsActive] = useState(false)
    const handleChange = (event, newValue) => {
        setValue(newValue);
    };

    function valuetext(value) {
        return `${value}`;
    }

    function filtered() {
        const newObj = data.filter((item) => {
            return (
                brand.length ? brand.includes(item.brand) : item
                    && battery.length ? battery.includes(item.battery) : item
                        && country.lenght ? country.includes(item.country) : item

                        && item.price > value[0]
                && item.price < value[1])
        })
        setProduct(newObj)
        console.log(product);
    }
    return (
        <div>
            <div className="container">
                <div className="telephones-nav">
                    <h1>Смартфоны в Ташкенте</h1>
                    <div className="filter-sen">
                        <span> <FaCoins />
                            По цене</span>
                        <span><BiMenuAltLeft />
                            По популярности</span>
                    </div>
                    <div className="boxe-icon">
                        <span style={isActive ? { color: "black" } : { color: "red" }} onClick={() => { setIsActive(false) }} ><IoGridOutline /></span>
                        <span style={isActive ? { color: "red" } : { color: "black" }} onClick={() => { setIsActive(true) }}><CiGrid2H /></span>
                    </div>
                </div>
                <div className="telephones-cards">
                    <div className="telephones-left-box">
                        <Accordion style={{ margin: "0px 0px 30px 0px" }}>
                            <AccordionSummary
                                expandIcon={<FaAngleDown />}
                                aria-controls="panel1-content"
                                id="panel1-header"
                            >
                                <p>Цена (cум)</p>

                            </AccordionSummary>
                            <AccordionDetails className='tel-box1'>
                                <div style={{ margin: "0px 0px 15px 0px" }}>
                                    <input value={`от ${value[0]}`} type="text" placeholder='от 300 000' />
                                    <input value={`до ${value[1]}`} type="text" placeholder='до 103 300 000' />


                                </div>
                                <Box sx={{ width: 300, }}>
                                    <Slider style={{ color: "#ED3729" }}
                                        getAriaLabel={() => 'Temperature range'}
                                        value={value}
                                        onChange={handleChange}
                                        // valueLabelDisplay="auto"
                                        min={30000}
                                        max={30000000}
                                        getAriaValueText={valuetext}
                                    />
                                </Box>
                            </AccordionDetails>
                        </Accordion>
                        <p className='zabrat-p'>Наличие</p>
                        <label className="zabrat">
                            <Checkbox style={{ color: "#ED3927" }} {...label} />
                            <p>Забрать сегодня</p>
                        </label>
                        <Accordion style={{ margin: "0px 0px 30px 0px" }}>
                            <AccordionSummary
                                expandIcon={<FaAngleDown />}
                                aria-controls="panel1-content"
                                id="panel1-header"
                            >
                                <p>Бренд</p>

                            </AccordionSummary>
                            <AccordionDetails onChange={(e) => {
                                if (!brand.includes(e.target.value)) {
                                    brand.push(e.target.value)
                                } else {
                                    const filterBrand = brand.filter((item) => {
                                        return item != e.target.value
                                    })
                                    setBrand(filterBrand)
                                }

                            }} className='tel-box1'>
                                <label className="zabrat red-none-border">
                                    <Checkbox value={"LG"} style={{ color: "#ED3927" }} {...label} />
                                    <label htmlFor="">LG (30)</label>
                                </label>
                                <label className="zabrat red-none-border">
                                    <Checkbox value={"Apple"} style={{ color: "#ED3927" }} {...label} />
                                    <label htmlFor="">Apple (30)</label>
                                </label>
                                <label className="zabrat red-none-border">
                                    <Checkbox value={"Artel"} style={{ color: "#ED3927" }} {...label} />
                                    <label htmlFor="">Artel (7)</label>
                                </label>
                                <label className="zabrat red-none-border">
                                    <Checkbox value={"Huawei"} style={{ color: "#ED3927" }} {...label} />
                                    <label htmlFor="">Huawei (30)</label>
                                </label>
                                <label className="zabrat red-none-border">
                                    <Checkbox value={"Hp"} style={{ color: "#ED3927" }} {...label} />
                                    <label htmlFor="">Hp (30)</label>
                                </label>

                            </AccordionDetails>
                        </Accordion>
                        <Accordion style={{ margin: "0px 0px 30px 0px" }}>
                            <AccordionSummary
                                expandIcon={<FaAngleDown />}
                                aria-controls="panel1-content"
                                id="panel1-header"
                            >
                                <p>Емкость аккумулятора</p>

                            </AccordionSummary>
                            <AccordionDetails onClick={(e) => {
                                if (!battery.includes(e.target.value)) {
                                    battery.push(e.target.value)
                                } else {
                                    const filterBattery = battery.filter((item) => {
                                        return item != e.target.value
                                    })
                                    setBattery(filterBattery)
                                }

                            }} className='tel-box1'>
                                <label className="zabrat red-none-border">
                                    <Checkbox value={'1821'} style={{ color: "#ED3927" }} {...label} />
                                    <label htmlFor="">1821 мА⋅ч</label>
                                </label>
                                <label className="zabrat red-none-border">
                                    <Checkbox value={'3000'} style={{ color: "#ED3927" }} {...label} />
                                    <label htmlFor="">3000 мА⋅ч</label>
                                </label>
                                <label className="zabrat red-none-border">
                                    <Checkbox value={'4000'} style={{ color: "#ED3927" }} {...label} />
                                    <label htmlFor="">4000 мА⋅ч</label>
                                </label>
                                <label className="zabrat red-none-border">
                                    <Checkbox value={'4500'} style={{ color: "#ED3927" }} {...label} />
                                    <label htmlFor="">4500 мА⋅ч</label>
                                </label>
                                <label className="zabrat red-none-border">
                                    <Checkbox value={'5000'} style={{ color: "#ED3927" }} {...label} />
                                    <label htmlFor="">5000 мА⋅ч</label>
                                </label>

                            </AccordionDetails>
                        </Accordion>
                        <Accordion style={{ margin: "0px 0px 30px 0px" }}>
                            <AccordionSummary
                                expandIcon={<FaAngleDown />}
                                aria-controls="panel1-content"
                                id="panel1-header"
                            >
                                <p>Страна производитель</p>

                            </AccordionSummary>
                            <AccordionDetails onChange={(e) => {
                                if (!country.includes(e.target.value)) {
                                    country.push(e.target.value)
                                } else {
                                    const filterCOuntry = country.filter((item) => {
                                        return item != e.target.value
                                    })
                                    setCountry(filterCOuntry)
                                }
                            }} className='tel-box1'>
                                <label className="zabrat red-none-border">
                                    <Checkbox value={"USA"} style={{ color: "#ED3927" }} {...label} />
                                    <label htmlFor="">USA</label>
                                </label>
                                <label className="zabrat red-none-border">
                                    <Checkbox value={"Xitoy"} style={{ color: "#ED3927" }} {...label} />
                                    <label htmlFor="">Китай</label>
                                </label>
                                <label className="zabrat red-none-border">
                                    <Checkbox value={"Uzbekistan"} style={{ color: "#ED3927" }} {...label} />
                                    <label htmlFor="">Uzb </label>
                                </label>
                                <label className="zabrat red-none-border">
                                    <Checkbox value={"Korea"} style={{ color: "#ED3927" }} {...label} />
                                    <label htmlFor="">Korea</label>
                                </label>

                            </AccordionDetails>
                        </Accordion>
                        <Accordion style={{ margin: "0px 0px 5px 0px" }}>
                            <AccordionSummary
                                expandIcon={<FaAngleDown />}
                                aria-controls="panel1-content"
                                id="panel1-header"
                            >
                                <p>Количество ядер</p>

                            </AccordionSummary>
                            <AccordionDetails className='tel-box1'>
                                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Tempore amet quos non eos repellat ipsum.
                            </AccordionDetails>
                        </Accordion>

                        <Accordion style={{ margin: "0px 0px  5px 0px" }}>
                            <AccordionSummary
                                expandIcon={<FaAngleDown />}
                                aria-controls="panel1-content"
                                id="panel1-header"
                            >
                                <p>Количество ядер</p>

                            </AccordionSummary>
                            <AccordionDetails className='tel-box1'>
                                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Tempore amet quos non eos repellat ipsum.
                            </AccordionDetails>
                        </Accordion>
                        <Accordion style={{ margin: "0px 0px  5px 0px" }}>
                            <AccordionSummary
                                expandIcon={<FaAngleDown />}
                                aria-controls="panel1-content"
                                id="panel1-header"
                            >
                                <p>Фотокамера</p>

                            </AccordionSummary>
                            <AccordionDetails className='tel-box1'>
                                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Tempore amet quos non eos repellat ipsum.
                            </AccordionDetails>
                        </Accordion>
                        <Accordion style={{ margin: "0px 0px  5px 0px" }}>
                            <AccordionSummary
                                expandIcon={<FaAngleDown />}
                                aria-controls="panel1-content"
                                id="panel1-header"
                            >
                                <p>Версия ОС</p>

                            </AccordionSummary>
                            <AccordionDetails className='tel-box1'>
                                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Tempore amet quos non eos repellat ipsum.
                            </AccordionDetails>
                        </Accordion>
                        <Accordion style={{ margin: "0px 0px  5px 0px" }}>
                            <AccordionSummary
                                expandIcon={<FaAngleDown />}
                                aria-controls="panel1-content"
                                id="panel1-header"
                            >
                                <p>Разъем для наушников</p>

                            </AccordionSummary>
                            <AccordionDetails className='tel-box1'>
                                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Tempore amet quos non eos repellat ipsum.
                            </AccordionDetails>
                        </Accordion>
                        <Accordion style={{ margin: "0px 0px 5px 0px" }}>
                            <AccordionSummary
                                expandIcon={<FaAngleDown />}
                                aria-controls="panel1-content"
                                id="panel1-header"
                            >
                                <p>MIcsuyb</p>

                            </AccordionSummary>
                            <AccordionDetails className='tel-box1'>
                                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Tempore amet quos non eos repellat ipsum.
                            </AccordionDetails>
                        </Accordion>
                        <div className="tel-box12">
                            <button onClick={filtered}  >Показать</button>
                        </div>
                    </div>
                    <div className="telephones-right-box">
                        <div className={isActive ? "telephones-right-main-box active" : "telephones-right-main-box"}>
                            {product?.map((item) => {
                                return <ToolCard  item={item} isActive={isActive} />
                            })}

                        </div>
                        <button className="ewe">
                            Показать еще
                        </button>
                        <div className="telephone-more-box">
                            <div className="tel-more-box-nav">
                                <h1>Популярные категории и модели</h1>
                                <div className="tel-nav-infos">
                                    <p>Realme</p>
                                    <p>Игровые</p>
                                    <p>Оптимальные</p>
                                    <p>Смартфоны Samsung</p>
                                    <p>Смартфоны Apple</p>
                                    <p>Смартфоны</p>
                                    <p>Смартфоны Samsung</p>
                                    <p>Смартфоны</p>
                                    <p>Игровые</p>
                                </div>
                            </div>
                            <div className="gar-info">
                                <h1>Товары которые так же могут быть интересны</h1>
                                <a href="">Посмотреть все</a>
                            </div>
                            <div className="gar-cards">
                                <ToolCard />
                                <ToolCard />
                                <ToolCard />
                            </div>
                        </div>
                        <div className="telefon-more">
                            <h1>Где купить надежный смартфон в Ташкенте?</h1>
                            <p className='disable-p disabled'>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus molestias adipisci veritatis ex labore delectus esse voluptates fugiat, sunt minima ad totam atque repellat quas? Impedit neque excepturi odit velit provident sapiente sed nam totam! Quidem suscipit veritatis adipisci temporibus a sequi eveniet voluptatem eos error hic quae rem molestiae veniam possimus praesentium, cumque vel repudiandae quis reiciendis ipsam, mollitia asperiores voluptatum. Commodi consectetur vero provident est error sed, saepe temporibus dignissimos corrupti, maiores, delectus deserunt nobis autem? Quisquam doloremque consequatur cupiditate excepturi labore possimus facilis architecto ullam ad! Delectus, repellendus qui. Non eligendi officiis dicta commodi at libero maxime voluptate nesciunt repellendus facere aut error impedit est earum beatae laudantium ea sequi expedita cum, harum et aliquam odio eius. Cum quisquam quos, molestiae obcaecati veniam distinctio minima earum unde pariatur dolores repudiandae sapiente consequatur at culpa delectus excepturi consequuntur! At consequuntur officiis quasi iusto minima molestias repellendus quia ab.</p>
                            <p>Показать больше</p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    )
}

export default Telephones