import React from 'react'
import './Laptop.css'
import { AiOutlineUser } from "react-icons/ai";
import { FaBalanceScale } from "react-icons/fa";
import { FaRegHeart } from "react-icons/fa6";
import { SlBasket } from "react-icons/sl";
import { useParams } from 'react-router-dom';

function Laptop({data}) {
    

    const {id}=useParams()

    const laptopItem = data.filter((item)=>{
        return item.id == id
    })
    console.log(laptopItem);
    return (
        <div>
            <div className="container">
                <div className="laptop">
                    <div className="laptop-left">
                        <div className="laptop-main-box">
                            <img src={laptopItem[0]?.img} alt="" />
                        </div>
                        <div className="laptop-imgs">
                            <img src="./public/imgs/laptop1.png" alt="" />
                            <img src="./public/imgs/laptop2.png" alt="" />
                            <img src="./public/imgs/laptop3.png" alt="" />
                            <img src="./public/imgs/laptop4.png" alt="" />
                        </div>
                    </div>
                    <div className="laptop-right">
                        <div className="laptop-right-left">
                            <h1>{laptopItem[0]?.name} <br /> </h1>
                            <div className="laptop-sum">
                                <h2>{laptopItem[0]?.price} cум</h2>
                                <div className="laptop-sum-icons">
                                    <span><SlBasket /></span>
                                    <span ><FaRegHeart /></span>
                                    <span><FaBalanceScale /></span>
                                </div>
                            </div>
                            <p> VIP скидки для VIP клиентов</p>
                            <div className="laptop-buttons">
                                <button className='laptop-button1' >Купить сейчас</button>
                                <button className='laptop-button2' >Купить в рассрочку сейчас</button>
                            </div>
                            <div className="laptop-top-infos">
                                <p>Название для договора</p>
                                <h5>{laptopItem[0]?.description}</h5>
                            </div>
                        </div>
                        <div className="laptop-right2">
                            <div className="right2-extras">
                                <h1>30 дней на обмен и возврат.</h1>
                                <p>Если купите товар сегодня, до 06 мая можете вернуть или обменять.</p>
                                <a href="#">Подробнее о программе.</a>
                            </div>
                            <div className="right2-extras">
                                <h1>30 дней на обмен и возврат.</h1>
                                <p>Если купите товар сегодня, до 06 мая можете вернуть или обменять.</p>
                                <a href="#">Подробнее о программе.</a>
                            </div>
                            <div className="right2-extras">
                                <h1>30 дней на обмен и возврат.</h1>
                                <p>Если купите товар сегодня, до 06 мая можете вернуть или обменять.</p>
                                <a href="#">Подробнее о программе.</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Laptop