import React from 'react'
import './Home.css'
import GarCard from '../../components/gar-card/GarCard'
import ToolCard from '../../components/tool-card/ToolCard'
import { Link } from 'react-router-dom'

function Home() {
  return (
    <div>
      <div className="container">
        <div className="header">
          <ul className="infos">
            <p>Категории</p>
            <li><a href="">Наши магазины</a></li>
            <li><a href="">Моноблоки</a></li>
            <li><Link to={'/telephones'} >Телефоны, планшеты</Link></li>
            <li><a href="">Ноутбуки</a></li>
            <li><a href="">Комплектующие</a></li>
            <li><a href="">Сетевое оборудование</a></li>
            <li><a href="">Оргтехника</a></li>
          </ul>
          <img src="./public/imgs/header.png" alt="" />
        </div>
        <div className="garyashei">
          <div className="gar-info">
            <h1>Горящие предложения</h1>
            <a href="">Посмотреть все</a>
          </div>
          <div className="gar-cards">
            <GarCard />
            <GarCard />
            <GarCard />
            <GarCard />
            <GarCard />
            <GarCard />
            <GarCard />
            <GarCard />
          </div>
        </div>
        <h1 className="category-title">Популярные категории</h1>
        <div className="category">
          <div>
            <h1>Компьютеры</h1>
            <img src="../public/imgs/laptop.png" alt="" />
          </div>
          <div>
            <h1>Телефоны, <br />
              планшеты</h1>
            <img src="../public/imgs/laptop.png" alt="" />
          </div>
          <div>
            <h1>Ноутбуки</h1>
            <img src="../public/imgs/laptop.png" alt="" />
          </div>
          <div>
            <h1>Товары для офиса</h1>
            <img src="../public/imgs/laptop.png" alt="" />
          </div>

        </div>

      </div>
      <div className="sell">
        <div className="container">
          <div className="sell-boxes">
            <div className='sell-left'>
              <h1>Apple iPhone X 64 ГБ</h1>
              <p>Совершенно новый дисплей Super Retina с диагональю 5,8 дюйма, который удобно лежит в руке и потрясающие выглядит, — это и есть iPhone X.</p>
            </div>
            <div className='sell-between'>
              <img className='sell-img' src="../public/imgs/sell.png" alt="" />
            </div>
            <div className='sell-right'>
              <h1>1 250 900 Сум</h1>
              <p>2 220  900 Сум</p>
              <a href="">Показать еще</a>
            </div>
          </div>
        </div>
      </div>
      <div className="container">
        <div className="gar-info">
          <h1>Товары дешевле:</h1>
          <a href="">Посмотреть все</a>
        </div>
        <div className="gar-cards">
          <ToolCard />
          <ToolCard />
          <ToolCard />
          <ToolCard />
          <ToolCard />
          <ToolCard />
          <ToolCard />
          <ToolCard />
        </div>
        <div className="gar-info">
          <h1>Рекомендуем</h1>
          <a href="">Посмотреть все</a>
        </div>
        <div className="rekomen">
          <div className="rekomen-left">
            <img src="../public/imgs/skidka.png" alt="" />
          </div>
          <div className="rekomen-right">
            <div className="gar-cards ">
              <ToolCard />
              <ToolCard />
              <ToolCard />
              <ToolCard />
              <ToolCard />
              <ToolCard />
            </div>
          </div>
        </div>
        <div className="gar-info">
          <h1>Бренды</h1>
          <a href="">--</a>
        </div>
        <div className="brend">
          <div className="brend-box">
            <img src="../public/imgs/brend.png" alt="" />
          </div>
          <div className="brend-box">
            <img src="../public/imgs/brend.png" alt="" />
          </div>
          <div className="brend-box">
            <img src="../public/imgs/brend.png" alt="" />
          </div>
          <div className="brend-box">
            <img src="../public/imgs/brend.png" alt="" />
          </div>
          <div className="brend-box">
            <img src="../public/imgs/brend.png" alt="" />
          </div>
        </div>
      </div>
    </div>
  )
}

export default Home